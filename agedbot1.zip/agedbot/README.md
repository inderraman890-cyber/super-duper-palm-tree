# Telegram Account Selling Bot 🤖

Deployable on VS Code and VPS (Ubuntu/Debian).

## Features
- **Auto SQLite DB Creation** (`bot.db`)
- **Inline Keyboards** with Wallet sub-parts (Add Balance, Promo Codes, Back, Cancel)
- **UPI QR Auto-Generation** (`8558869772@okaxis`)
- **Admin Verification Panel** for TXN ID & Screenshots
- **Premium Button Styling** & Sticker support

## Installation
1. Install Python 3.10+
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the bot:
   ```bash
   python bot.py
   ```
